export interface SomeAssociate {
    firstName: string;
    lastName: string;
    role: string;
    email: string;
 }
 