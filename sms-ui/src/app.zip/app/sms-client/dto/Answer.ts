export interface Answer {
    id: number;
    answer: string;
    questionId: number;
  }
