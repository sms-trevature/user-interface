export interface Cohort {
    CName: String; 
    address: String; 
    Token: String; 
    StartD: String; 
    EndD: String; 
    trainer: String; 
    Email: String; 
}