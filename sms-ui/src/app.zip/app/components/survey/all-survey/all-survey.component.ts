import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-survey',
  templateUrl: './all-survey.component.html',
  styleUrls: ['./all-survey.component.scss']
})
export class AllSurveyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
