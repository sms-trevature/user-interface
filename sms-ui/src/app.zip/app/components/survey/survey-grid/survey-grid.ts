export interface Isurvey {
  Title: string;
  Description: string;
  DateCreated: string;
}
