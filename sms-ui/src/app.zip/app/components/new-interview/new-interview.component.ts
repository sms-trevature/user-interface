import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-interview',
  templateUrl: './new-interview.component.html',
  styleUrls: ['./new-interview.component.scss']
})
export class NewInterviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
